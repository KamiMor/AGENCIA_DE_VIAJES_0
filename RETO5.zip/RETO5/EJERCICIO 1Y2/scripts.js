function calcularRectangulo() {
    const base = parseFloat(document.getElementById('base').value);
    const altura = parseFloat(document.getElementById('altura').value);

    // Validación de entrada
    if (isNaN(base) || isNaN(altura) || base <= 0 || altura <= 0) {
        alert('Por favor, ingrese valores válidos para base y altura. Ambos deben ser mayores a cero.');
        return;
    }

    // Cálculos
    const area = base * altura;
    const perimetro = 2 * (base + altura);
    const diagonal = Math.sqrt(base ** 2 + altura ** 2);

    // Mostrar resultados
    document.getElementById('areaRectangulo').innerText = area;
    document.getElementById('perimetroRectangulo').innerText = perimetro;
    document.getElementById('diagonalRectangulo').innerText = diagonal.toFixed(0);
}

function calcularCirculo() {
    const radio = parseFloat(document.getElementById('radio').value);

    // Validación de entrada
    if (isNaN(radio) || radio <= 0) {
        alert('Por favor, ingrese un valor válido para el radio. Debe ser mayor a cero.');
        return;
    }

    // Cálculos
    const area = Math.PI * radio ** 2;
    const perimetro = 2 * Math.PI * radio;

    // Mostrar resultados
    document.getElementById('areaCirculo').innerText = area.toFixed(0);
    document.getElementById('perimetroCirculo').innerText = perimetro.toFixed(0);
}